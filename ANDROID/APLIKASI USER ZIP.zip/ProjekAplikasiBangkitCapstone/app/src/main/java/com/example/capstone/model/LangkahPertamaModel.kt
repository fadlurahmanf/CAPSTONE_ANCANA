package com.example.capstone.model

data class LangkahPertamaModel(
    var todo: String? = null,
    var detail: String? = null
)