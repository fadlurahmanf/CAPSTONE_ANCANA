package com.example.capstone.model

data class PenanggulanganBencanaModel(
    var name:String?=null,
    var photo:Int?=0
)
