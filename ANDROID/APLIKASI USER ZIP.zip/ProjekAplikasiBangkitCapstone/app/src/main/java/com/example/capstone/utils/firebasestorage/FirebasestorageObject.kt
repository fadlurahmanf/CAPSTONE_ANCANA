package com.example.capstone.utils.firebasestorage

object FirebasestorageObject {
    internal class DisasterCaseDataStorage{
        companion object{
            const val DISASTER_CASE_FOLDER_NAME = "disasterCaseData"
            const val USERDATA_FOLDER_NAME = "userData"
        }
    }
}