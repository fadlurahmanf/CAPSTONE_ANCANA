package com.example.capstone.utils.database

class DatabaseHelper {
    companion object{
        const val DATABASE_NAME = "capstoneDatabase.db"
        const val DATABASE_VERSION = 1
    }
}